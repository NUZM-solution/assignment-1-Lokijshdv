using System.Data;
using System.Drawing.Printing;

namespace grid
{
    public partial class Form1 : Form
    {
        private DataTable dt;
        private PrintDocument printDocument = new PrintDocument();
        public Form1()
        {
            InitializeComponent();
            InitializeDataTable();
            printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
        }
        private void InitializeDataTable()
        {
            dt = new DataTable();
            dt.Columns.Add(new DataColumn("Course Code", typeof(int)));
            dt.Columns.Add(new DataColumn("Course Title", typeof(string)));
            dt.Columns.Add(new DataColumn("Obtain Marks", typeof(int)));
            dt.Columns.Add(new DataColumn("Course Grade", typeof(char)));
            dt.Columns.Add(new DataColumn("Course Status", typeof(string)));
            dataGridView1.DataSource = dt; // Set the DataSource once
        }
        public void createnewrow()
        {
            // Validate input and parse appropriately
            int courseId;
            double creditHour;
            char courseGrade;
            string courseName = textBox2.Text;
            string courseStatus = textBox5.Text;
            if (int.TryParse(textBox1.Text, out courseId) &&
                double.TryParse(textBox3.Text, out creditHour) &&
                char.TryParse(textBox4.Text, out courseGrade))
            {
                dt.Rows.Add(courseId, courseName, creditHour, courseGrade, courseStatus);
            }
            else
            {
                MessageBox.Show("Please enter valid data.");
            }
        }
        private void PrintPreview()
        {
            PrintPreviewDialog previewDialog = new PrintPreviewDialog();
            previewDialog.Document = printDocument;
            previewDialog.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Print the DataGridView content
            Bitmap bitmap = new Bitmap(dataGridView1.Width, dataGridView1.Height);
            dataGridView1.DrawToBitmap(bitmap, new Rectangle(0, 0, dataGridView1.Width, dataGridView1.Height));
            e.Graphics.DrawImage(bitmap, 0, 0);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            createnewrow();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)

        { }
        private void label2_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            PrintPreview();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            createnewrow();

        }
    }
}



